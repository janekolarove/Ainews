
# Codespaces Quickstart for AI News.run

This addon lets you configure and deploy the site with **one Codespaces session**.

## Steps

1. Create a **public** GitHub repo named `ainews-run`.
2. Upload the **starter ZIP** contents (all files) to the repo.
3. Upload this **Codespaces addon** (keep folder structure). You should have:
   - `.devcontainer/devcontainer.json`
   - `scripts/bootstrap.sh`
4. Open the repo → **Code → Create codespace on main**.
5. In the Codespaces terminal run:
   ```bash
   bash scripts/bootstrap.sh
   ```
   • Enter your `OPENAI_API_KEY` when prompted.  
   • Enter your AdSense Publisher ID (`pub-...`).  
   The script will set repo secrets, update config, build, commit & push.

6. Wait for **Build and Deploy (GitHub Pages)** workflow to finish (Actions tab).  
   The site will appear in **Settings → Pages**.

7. (Recommended) Set **Custom domain** = `ainews.run`, enable **Enforce HTTPS**, and set DNS at Wedos:
   - A @ → 185.199.108.153
   - A @ → 185.199.109.153
   - A @ → 185.199.110.153
   - A @ → 185.199.111.153
   - CNAME www → `yourusername.github.io`

8. The **Auto Content (Daily AI posts)** workflow runs 3×/day and commits new CZ/EN posts automatically.

––
If you want to adjust frequency or topics, edit `.github/workflows/auto-content.yml` and `scripts/generate_posts.py`.

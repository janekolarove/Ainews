
#!/usr/bin/env bash
set -e

MODE="${1:-}"
REPO="${GITHUB_REPOSITORY:-}"

if [[ "$MODE" == "--prepare" ]]; then
  echo "🔧 Preparing Codespace environment..."
  echo "• Checking Ruby & Bundler"
  ruby -v || true
  gem install bundler || true
  if [[ -f "Gemfile" ]]; then
    bundle install || true
  fi
  echo "✅ Prep done. Run: bash scripts/bootstrap.sh to set secrets & deploy."
  exit 0
fi

echo "🚀 AI News.run bootstrap — set secrets, update config, build & deploy"

# 1) OPENAI_API_KEY
if [[ -z "${OPENAI_API_KEY}" ]]; then
  read -rsp "Enter your OPENAI_API_KEY: " OPENAI_API_KEY
  echo
fi
echo "• Storing OPENAI_API_KEY as repo secret..."
gh secret set OPENAI_API_KEY -b"$OPENAI_API_KEY"

# 2) AdSense client ID (pub-...)
if [[ -z "${ADSENSE_CLIENT}" ]]; then
  read -rp "Enter your AdSense Publisher ID (e.g., pub-1234567890123456): " ADSENSE_CLIENT
fi

echo "• Writing AdSense ID to _config.yml and ads.txt"
if [[ -f "_config.yml" ]]; then
  sed -i "s/adsense_client: \".*\"/adsense_client: \"${ADSENSE_CLIENT}\"/g" _config.yml
fi

if [[ -f "ads.txt" ]]; then
  sed -i "s/pub-XXXXXXXXXXXXXXXX/${ADSENSE_CLIENT}/g" ads.txt
fi

# 3) Build site
echo "• Installing gems & building site"
bundle install
bundle exec jekyll build

# 4) Commit & push
echo "• Committing changes"
git config user.name "ai-news-bot"
git config user.email "bot@ainews.run"
git add _config.yml ads.txt || true
git add Gemfile* .github _posts assets .devcontainer scripts || true
if git diff --cached --quiet; then
  echo "No changes to commit."
else
  git commit -m "bootstrap: configure AdSense & setup workflows"
  git push
fi

echo "• Triggering Build & Deploy workflow (if not auto-triggered by push)"
gh workflow run "Build and Deploy (GitHub Pages)" || true

echo "✅ Bootstrap complete."
echo "Next steps:"
echo "  1) Repo → Settings → Pages → ensure 'Build and Deploy' ran and site URL is visible."
echo "  2) Add custom domain in Settings → Pages (ainews.run) and set DNS at Wedos (A x4 + CNAME www)."
echo "  3) Auto Content workflow runs 3× denně. You can dispatch it manually from the Actions tab."
